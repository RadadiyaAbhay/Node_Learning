const notificationClose = (k) => {
    const notify = document.getElementById(`notify${k}`);
    notify.style.display = "none";
}